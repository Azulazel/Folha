# Folha para Android

Código web em `www/`; integração nativa em `src/native.js`; projeto Android Studio em `android/`.

```powershell
npm ci
npm run android:sync
npm run android:open
```

Requisitos: Node.js 22+, Android Studio 2025.2.1+ e Android SDK 36. Utilize o JDK integrado do Android Studio.

Leia `COMO-PUBLICAR-FOLHA.md`, na raiz do ZIP, para gerar o AAB assinado e preparar a publicação. O projeto Android foi gerado e sincronizado, mas ainda precisa ser compilado e testado em dispositivo/emulador. Nenhum APK ou AAB está incluído. O aplicativo não foi publicado na Google Play.

Identificador inicial: `com.asael.folha`. Confirme o identificador e os dados do responsável antes de publicar.

O PDF exportado é compartilhado pelo seletor nativo do Android. Os documentos ficam no armazenamento local do app. A leitura normal usa os recursos incorporados. OCR usa downloads HTTPS externos e deve ser testado no aparelho.

`docs/POLITICA-DE-PRIVACIDADE-RASCUNHO.md` requer revisão, contato real e publicação em URL pública antes do lançamento.

O projeto não contém chaves de assinatura, tokens, conta de loja nem configuração do site privado. Licenças das bibliotecas estão em `www/vendor/`.
