package com.asael.folha;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
