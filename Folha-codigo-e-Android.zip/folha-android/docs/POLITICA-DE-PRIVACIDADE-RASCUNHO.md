# RASCUNHO — Política de privacidade do Folha

**Preencher responsável, contato e data; revisar e publicar uma versão final pública antes do envio à loja. Este rascunho não é uma política já publicada.**

Responsável: [NOME DO DESENVOLVEDOR OU EMPRESA]

Contato para privacidade e suporte: [E-MAIL DE CONTATO]

Última atualização: [DATA DA VERSÃO PUBLICADA]

## Funcionamento

O Folha é um leitor de PDFs com reorganização do texto, preferências de leitura, reconhecimento de texto e exportação de uma cópia adaptada. Não é necessário criar uma conta no aplicativo.

## Arquivos e preferências

Os PDFs escolhidos pelo usuário, o texto extraído ou corrigido, a posição de leitura e as preferências são armazenados localmente no aplicativo. O código desta versão não envia PDFs ou textos para um servidor do responsável pelo Folha e não contém publicidade ou ferramentas de análise de uso.

## Reconhecimento de texto e acesso à rede

O reconhecimento de texto é realizado no aparelho. Para disponibilizá-lo, o aplicativo pode baixar componentes e dados de idiomas por conexões HTTPS com jsDelivr e Project Naptha. Esses serviços recebem as informações técnicas necessárias à conexão, como endereço IP e dados da requisição. O arquivo PDF não é incluído nessas solicitações de download pelo aplicativo.

Os termos e políticas desses provedores devem ser consultados nas versões vigentes: https://www.jsdelivr.com/ e https://projectnaptha.com/ .

## Exportação e compartilhamento

Ao exportar, o app cria um PDF temporário em seu cache e abre o seletor de compartilhamento do Android. A cópia só é encaminhada ao destino escolhido pelo usuário. O tratamento realizado pelo aplicativo de destino está sujeito às regras desse destino.

## Exclusão e retenção

Os itens da estante podem ser removidos individualmente pelo próprio aplicativo. Limpar os dados do app nas configurações do Android ou desinstalá-lo remove o armazenamento local do app. Os PDFs exportados para outros aplicativos ou locais precisam ser apagados nesses destinos. Cópias temporárias de exportação ficam no cache até a limpeza pelo Android ou pelo usuário.

## Permissões

A versão fornecida usa acesso à internet para os downloads do reconhecedor de texto. Os documentos são selecionados pelo usuário com o seletor de arquivos do sistema. O app não solicita acesso amplo a todos os arquivos, contatos, câmera, microfone ou localização.

## Contato e alterações

Dúvidas e solicitações sobre privacidade podem ser encaminhadas ao contato indicado no início desta política. Alterações nas funções, nos provedores ou nas práticas de dados exigem atualização deste documento e das declarações na loja.
