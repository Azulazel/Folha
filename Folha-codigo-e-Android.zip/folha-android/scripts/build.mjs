import {build} from 'esbuild';
await build({entryPoints:['src/native.js'],outfile:'www/native.js',bundle:true,format:'iife',target:'es2020',minify:true});
console.log('Native adapter built. Run npx cap sync android after changing www.');
