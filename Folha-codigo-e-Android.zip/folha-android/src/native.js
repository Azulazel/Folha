import {Capacitor} from '@capacitor/core';
import {Filesystem,Directory} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';
import {App} from '@capacitor/app';
function encode(buffer){const b=new Uint8Array(buffer);let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s)}
if(Capacitor.isNativePlatform()){
  window.FolhaNative={async savePDF(buffer,name){
    const safe=name.replace(/[<>:"/\\|?*]/g,'_').slice(0,120);
    const path='folha-exports/'+Date.now()+'-'+safe;
    await Filesystem.writeFile({path,directory:Directory.Cache,data:encode(buffer),recursive:true});
    const {uri}=await Filesystem.getUri({path,directory:Directory.Cache});
    await Share.share({title:'PDF de leitura',files:[uri],dialogTitle:'Salvar ou compartilhar PDF'});
  }};
  document.addEventListener('DOMContentLoaded',()=>{const el=document.querySelector('#install');if(el)el.hidden=true});
  App.addListener('backButton',()=>{
    const dialogs=[...document.querySelectorAll('dialog[open]')];
    if(dialogs.length){dialogs.at(-1).close();return}
    if(!document.querySelector('#busy').hidden)return;
    if(!document.querySelector('#reader').hidden){document.querySelector('#back').click();return}
    App.minimizeApp();
  });
}
